<template>
  <div
    ref="editor"
    class="editor"
    tabindex="0"
    @keydown="onKeyDown"
    @mousedown="onMouseDown"
  >
    <template v-for="(bloco, index) in model.conteudo">
      <span
        v-if="bloco.texto"
        :key="index"
        :class="getClass(bloco.estilos)"
      >
        {{ bloco.texto }}
      </span>
      <br v-else />
    </template>
    <!-- Caret visual -->
    <span
      v-if="showCaret"
      class="caret"
      :style="{ left: caretPos.x + 'px', top: caretPos.y + 'px' }"
    ></span>
  </div>
</template>

<script setup>
import { ref, nextTick, onMounted } from 'vue'

const editor = ref(null)
const model = defineModel([
  { texto: '', estilos: {} } // modelo inicial
])

const caretPos = ref({ x: 0, y: 0 })
const caretIndex = ref({ bloco: 0, offset: 0 })
const showCaret = ref(true)

// Foco ao montar
onMounted(() => {
  editor.value.focus()
  updateCaret()
})

// --- Funções de foco ---
function onMouseDown(e) {
  e.preventDefault()
  editor.value.focus()
  // calcula posição aproximada do caret pelo clique
  nextTick(updateCaret)
}

// --- Key Handling ---
function onKeyDown(e) {
  e.preventDefault()
  const bloco = model.value[caretIndex.value.bloco]
  console.log(caretIndex.value)
  // Letras e números
  if (e.key.length === 1) {
    const texto = bloco.texto || ''
    const newTexto = texto.slice(0, caretIndex.value.offset) + e.key + texto.slice(caretIndex.value.offset)
    bloco.texto = newTexto
    caretIndex.value.offset++
    nextTick(updateCaret)
    return
  }

  // Backspace
  if (e.key === 'Backspace') {
    if (caretIndex.value.offset > 0) {
      const texto = bloco.texto
      bloco.texto = texto.slice(0, caretIndex.value.offset - 1) + texto.slice(caretIndex.value.offset)
      caretIndex.value.offset--
    } else if (caretIndex.value.bloco > 0) {
      // merge com bloco anterior
      const prev = model.value[caretIndex.value.bloco - 1]
      caretIndex.value.offset = prev.texto.length
      prev.texto += bloco.texto
      model.value.splice(caretIndex.value.bloco, 1)
      caretIndex.value.bloco--
    }
    nextTick(updateCaret)
    return
  }

  // Enter
  if (e.key === 'Enter') {
    const texto = bloco.texto
    const antes = texto.slice(0, caretIndex.value.offset)
    const depois = texto.slice(caretIndex.value.offset)
    bloco.texto = antes
    const novoBloco = { texto: depois, estilos: { ...bloco.estilos } }
    model.value.splice(caretIndex.value.bloco + 1, 0, novoBloco)
    caretIndex.value.bloco++
    caretIndex.value.offset = 0
    nextTick(updateCaret)
    return
  }
}

// --- Helpers ---
function updateCaret() {
  // mínimo: coloca caret no final do bloco atual
  const range = document.createRange()
  const sel = window.getSelection()
  const blocoEl = editor.value.childNodes[caretIndex.value.bloco * 2] // contando <br> alternando
  if (!blocoEl) return

  let node = blocoEl.firstChild || blocoEl
  let offset = Math.min(caretIndex.value.offset, node.textContent?.length || 0)
  range.setStart(node, offset)
  range.collapse(true)
  sel.removeAllRanges()
  sel.addRange(range)
}

// --- Classe de estilo ---
function getClass(estilos = {}) {
  const classes = []
  if (estilos.bold) classes.push('txt-bold')
  if (estilos.italic) classes.push('txt-italic')
  if (estilos.underline) classes.push('txt-underline')
  return classes.join(' ')
}
</script>

<style scoped>
.editor {
  border: 1px solid #ccc;
  min-height: 2em;
  padding: 4px;
  outline: none;
  user-select: text;
  white-space: pre-wrap;
}

.txt-bold {
  font-weight: bold;
}
.txt-italic {
  font-style: italic;
}
.txt-underline {
  text-decoration: underline;
}

.caret {
  display: inline-block;
  width: 1px;
  background: black;
  height: 1em;
  position: absolute;
}
</style>
