<template>
    <h1
      v-for="(chunk, i) in data.conteudo"
      :key="i"
      :class="chunk.estilos"
    >
      {{ chunk.texto }}
    </h1>
</template>
<script setup>
const data = defineModel()
</script>