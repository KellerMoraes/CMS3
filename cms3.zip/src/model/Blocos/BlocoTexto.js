export class BlocoTexto {
  constructor(texto = "") {
    return [
      { texto: "Olá Mundo", estilos: {} },
    ];
  }
}
